(()=>{'use strict';
const $=i=>document.getElementById(i),R=Math.random,rr=(a,b)=>a+R()*(b-a),cl=(v,a,b)=>Math.max(a,Math.min(b,v));
window.onerror=(m,s,l)=>{const e=$('err');e.style.display='block';e.textContent='Erro: '+m+' (linha '+l+')'};
if(!window.THREE){$('ld').textContent='Falha ao carregar o Three.js (verifique a internet).';return}
const T=THREE;
/* ===== SAVE ===== */
const P={x:0,z:20,yaw:0,pitch:0,bob:0};
const Save={k:'lastsignal_v01',d:{f:{},items:[],p:[0,20,0]},
load(){try{const s=localStorage.getItem(this.k);if(s){Object.assign(this.d,JSON.parse(s));return true}}catch(e){}return false},
put(){try{this.d.p=[P.x,P.z,P.yaw];localStorage.setItem(this.k,JSON.stringify(this.d))}catch(e){}},
reset(){try{localStorage.removeItem(this.k)}catch(e){}this.d={f:{},items:[],p:[0,20,0]}}};
/* ===== UI ===== */
let subT=0;const sub=(t,ms=4500)=>{$('sub').textContent=t;clearTimeout(subT);if(ms)subT=setTimeout(()=>$('sub').textContent='',ms)};
const showDoc=(t,x)=>{$('dt').textContent=t;$('dx').textContent=x;$('doc').style.display='block'};
$('dc').onclick=()=>$('doc').style.display='none';$('rc').onclick=()=>{$('rad').style.display='none';Radio.open=false};
/* ===== AUDIO ===== */
const A={c:null,
init(){if(this.c)return;const c=this.c=new(window.AudioContext||window.webkitAudioContext)();this.m=c.createGain();this.m.gain.value=.85;this.m.connect(c.destination);
const b=c.createBuffer(1,c.sampleRate*2,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=R()*2-1;this.nb=b;
const w=this.chain('lowpass',380,1,.3),o=c.createOscillator(),og=c.createGain();o.frequency.value=.12;og.gain.value=.18;o.connect(og);og.connect(w.gain);o.start();
this.chain('highpass',2600,.5,.06);this.st=this.chain('bandpass',2200,.6,0);
this.wh=c.createGain();this.wh.gain.value=0;const ws=c.createOscillator();ws.frequency.value=1150;ws.connect(this.wh);this.wh.connect(this.m);ws.start()},
ns(){const s=this.c.createBufferSource();s.buffer=this.nb;s.loop=true;s.start();return s},
chain(t,f,q,g){const c=this.c,fl=c.createBiquadFilter();fl.type=t;fl.frequency.value=f;fl.Q.value=q;const gn=c.createGain();gn.gain.value=g;this.ns().connect(fl);fl.connect(gn);gn.connect(this.m);return gn},
out(n,p){if(!p){n.connect(this.m);return}const pn=this.c.createPanner();pn.panningModel='equalpower';pn.refDistance=3;if(pn.positionX){pn.positionX.value=p.x;pn.positionY.value=p.y;pn.positionZ.value=p.z}else pn.setPosition(p.x,p.y,p.z);n.connect(pn);pn.connect(this.m)},
tone(a,b,d,v,type,p){if(!this.c)return;const c=this.c,o=c.createOscillator(),g=c.createGain(),t=c.currentTime;o.type=type;o.frequency.setValueAtTime(a,t);o.frequency.linearRampToValueAtTime(b,t+d);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+d*.3);g.gain.linearRampToValueAtTime(0,t+d);o.connect(g);this.out(g,p);o.start();o.stop(t+d+.05)},
burst(f,d,v,p){if(!this.c)return;const c=this.c,s=c.createBufferSource(),fl=c.createBiquadFilter(),g=c.createGain(),t=c.currentTime;s.buffer=this.nb;fl.type='lowpass';fl.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);s.connect(fl);fl.connect(g);this.out(g,p);s.start(0,R());s.stop(t+d)},
creak(p){this.tone(rr(60,90),rr(100,160),rr(.7,1.4),.18,'sawtooth',p)},
listen(){if(!this.c)return;const L=this.c.listener,fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);if(L.positionX){L.positionX.value=P.x;L.positionY.value=1.7;L.positionZ.value=P.z;L.forwardX.value=fx;L.forwardY.value=0;L.forwardZ.value=fz;L.upX.value=0;L.upY.value=1;L.upZ.value=0}else{L.setPosition(P.x,1.7,P.z);L.setOrientation(fx,0,fz,0,1,0)}}};
/* ===== RADIO ===== */
const L1='Se alguém estiver ouvindo... meu nome é Elena. Estou presa aqui há 15 anos. Por favor, não deixem que eles me encontrem.',L2='Eu sei que você está me ouvindo. Mas... como você sabe meu nome?';
const Radio={open:false,f:100,T:93.7,stage:0,id:0,speaking:false,
near(){return Math.max(0,1-Math.abs(this.f-this.T)/1.2)},
say(t,cb){sub('ELENA (rádio): “'+t+'”',0);this.speaking=true;let done=false;const fin=()=>{if(done)return;done=true;this.speaking=false;cb()};
if(!window.speechSynthesis||!window.SpeechSynthesisUtterance){setTimeout(fin,7000);return}
const u=new SpeechSynthesisUtterance(t);u.lang='pt-BR';u.pitch=.6;u.rate=.82;const v=speechSynthesis.getVoices().find(x=>/pt[-_]BR/i.test(x.lang));if(v)u.voice=v;u.onend=u.onerror=fin;speechSynthesis.speak(u)},
play(){this.stage=1;const id=++this.id;this.say(L1,()=>{if(id!==this.id)return;setTimeout(()=>{if(id!==this.id)return;this.stage=2;this.say(L2,()=>{if(id!==this.id)return;this.stage=3;Save.d.f.radio=1;sub('A voz some na estática.',5000);check()})},4000)})},
stop(){this.id++;try{speechSynthesis.cancel()}catch(e){}this.speaking=false;this.stage=0;sub('')},
update(){if(!A.c)return;const n=this.near(),o=this.open;
const sg=o?(this.speaking?.05:.3*(1-n*.9)):0;A.st.gain.value+=(sg-A.st.gain.value)*.2;
A.wh.gain.value=o&&n>.1&&n<.85?.03*Math.sin(n*Math.PI):0;
if(o&&n>.8&&this.stage===0&&!Save.d.f.radio)this.play();
if(this.stage>0&&this.stage<3&&(!o||n<.5))this.stop();
$('mb').style.width=(n*100)+'%'}};
$('sl').oninput=e=>{Radio.f=e.target.value/10;$('fr').textContent=Radio.f.toFixed(1);A.burst(2500,.06,.15)};
const openRadio=()=>{Radio.open=!Radio.open;$('rad').style.display=Radio.open?'block':'none';if(Radio.open)sub('Preciso achar a frequência certa...',3500)};
/* ===== INVENTÁRIO ===== */
const Inv={give(id,t,x){if(!Save.d.items.find(i=>i.id===id))Save.d.items.push({id,t,x});Save.put();showDoc(t,x)},
list(){const i=Save.d.items;if(!i.length)showDoc('Notas','Nada ainda.');else showDoc('Notas ('+i.length+')',i.map(k=>'■ '+k.t+'\n'+k.x).join('\n\n'))}};
$('bNotes').onclick=()=>Inv.list();
function check(){const f=Save.d.f;if(f.car&&f.shed&&f.radio&&!f.end){f.end=1;setTimeout(()=>sub('Fim da demonstração V0.1. A estrada para Blackwood continua...',9000),3000)}}
/* ===== MUNDO ===== */
const sc=new T.Scene(),FOG=0x0a1018;sc.background=new T.Color(FOG);sc.fog=new T.FogExp2(FOG,.05);
const cam=new T.PerspectiveCamera(72,1,.1,95);sc.add(cam);
const rd=new T.WebGLRenderer({antialias:false,powerPreference:'high-performance'});document.body.prepend(rd.domElement);
sc.add(new T.HemisphereLight(0x3a527a,0x0c0f0a,.55));const moon=new T.DirectionalLight(0x6d86c0,.35);moon.position.set(-20,40,10);sc.add(moon);
function tex(base,rgb,rep,rx=1,w=64){const c=document.createElement('canvas');c.width=c.height=w;const g=c.getContext('2d');g.fillStyle=base;g.fillRect(0,0,w,w);for(let i=0;i<w*w/3;i++){g.fillStyle='rgba('+rgb+','+R()*.5+')';g.fillRect(R()*w|0,R()*w|0,1+R()*2|0,1)}const t=new T.CanvasTexture(c);t.magFilter=t.minFilter=T.NearestFilter;t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rep,rep*rx);return t}
const mat=(c,t)=>new T.MeshPhongMaterial({color:c,map:t||null,flatShading:true,shininess:0});
function box(x1,x2,y1,y2,z1,z2,m){const b=new T.Mesh(new T.BoxGeometry(x2-x1,y2-y1,z2-z1),m);b.position.set((x1+x2)/2,(y1+y2)/2,(z1+z2)/2);sc.add(b);return b}
const gnd=new T.Mesh(new T.PlaneGeometry(200,260),mat(0xffffff,tex('#1b2a1d','0,0,0',70)));gnd.rotation.x=-Math.PI/2;sc.add(gnd);
const rc=document.createElement('canvas');rc.width=64;rc.height=64;{const g=rc.getContext('2d');g.fillStyle='#2b2d30';g.fillRect(0,0,64,64);for(let i=0;i<900;i++){g.fillStyle='rgba(0,0,0,'+R()*.5+')';g.fillRect(R()*64|0,R()*64|0,2,1)}g.fillStyle='#8a7b34';g.fillRect(31,4,2,22)}
const rt=new T.CanvasTexture(rc);rt.magFilter=rt.minFilter=T.NearestFilter;rt.wrapS=rt.wrapT=T.RepeatWrapping;rt.repeat.set(1,40);
const road=new T.Mesh(new T.PlaneGeometry(7,260),mat(0xffffff,rt));road.rotation.x=-Math.PI/2;road.position.y=.02;sc.add(road);
/* colisão */
const walls=[],trees=[],Fx={};
function wall(x1,x2,z1,z2,h,m){walls.push({x1,x2,z1,z2});return box(x1,x2,0,h,z1,z2,m)}
/* floresta (instanciada) */
{const N=230,tm=new T.InstancedMesh(new T.CylinderGeometry(.18,.3,3,5),mat(0xffffff,tex('#3a2c20','0,0,0',1)),N),
c1=new T.InstancedMesh(new T.ConeGeometry(1.7,3.4,6),mat(0x1d3a2a),N),c2=new T.InstancedMesh(new T.ConeGeometry(1.2,2.8,6),mat(0x23442f),N),d=new T.Object3D();
for(let i=0;i<N;i++){let x,z,k=0;do{x=rr(-48,48);z=rr(-105,35);k++}while(k<30&&(Math.abs(x)<5.5||Math.hypot(x+4.2,z+18)<5||(x>3&&x<16&&z>-42&&z<-27)||Math.hypot(x,z-20)<4));
trees.push({x,z});const s=rr(.8,1.5),ry=R()*6;
d.rotation.set(rr(-.06,.06),ry,rr(-.06,.06));d.scale.set(s,s,s);d.position.set(x,1.5*s,z);d.updateMatrix();tm.setMatrixAt(i,d.matrix);
d.position.y=4.3*s;d.updateMatrix();c1.setMatrixAt(i,d.matrix);d.position.y=6.1*s;d.scale.set(s*.8,s*.8,s*.8);d.updateMatrix();c2.setMatrixAt(i,d.matrix)}
sc.add(tm,c1,c2);
const bm=new T.InstancedMesh(new T.IcosahedronGeometry(.8,0),mat(0x16281a),110);for(let i=0;i<110;i++){let x=rr(-40,40);if(Math.abs(x)<4.5)x+=x<0?-6:6;d.rotation.set(0,R()*6,0);d.scale.set(rr(.7,1.6),rr(.5,1),rr(.7,1.6));d.position.set(x,.3,rr(-100,30));d.updateMatrix();bm.setMatrixAt(i,d.matrix)}sc.add(bm)}
/* placa */
{const c=document.createElement('canvas');c.width=256;c.height=128;const g=c.getContext('2d');g.fillStyle='#1f3b2c';g.fillRect(0,0,256,128);g.strokeStyle='#cfd8d0';g.lineWidth=5;g.strokeRect(6,6,244,116);g.fillStyle='#cfd8d0';g.font='bold 34px Arial';g.textAlign='center';g.fillText('BLACKWOOD',128,62);g.font='26px Arial';g.fillText('4 KM',128,100);
const t=new T.CanvasTexture(c);t.magFilter=T.NearestFilter;const s=new T.Mesh(new T.PlaneGeometry(2.2,1.1),mat(0xffffff,t));s.position.set(4.2,2.3,-4);s.rotation.y=.25;sc.add(s);const p=new T.Mesh(new T.CylinderGeometry(.06,.06,2.4,5),mat(0x444444));p.position.set(4.2,1.2,-4.05);sc.add(p)}
/* carro abandonado */
const carP=new T.Vector3(-4.2,0,-18);
{const g=new T.Group(),bm=mat(0x5b2424),gm=mat(0x1a2530);const b=(w,h,d,x,y,z,m)=>{const q=new T.Mesh(new T.BoxGeometry(w,h,d),m);q.position.set(x,y,z);g.add(q)};
b(1.9,.7,4.4,0,.65,0,bm);b(1.7,.65,2.3,0,1.3,-.2,gm);b(1.9,.1,2.3,0,1.65,-.2,bm);
[[-.95,1.4],[.95,1.4],[-.95,-1.4],[.95,-1.4]].forEach(p=>{const w=new T.Mesh(new T.CylinderGeometry(.36,.36,.25,8),mat(0x111111));w.rotation.z=Math.PI/2;w.position.set(p[0],.36,p[1]);g.add(w)});
g.position.copy(carP);g.rotation.y=.5;sc.add(g);const pl=new T.PointLight(0xc88a3a,.9,9);pl.position.set(-4.2,1.5,-18);sc.add(pl);Fx.carL=pl;
walls.push({x1:-5.6,x2:-2.8,z1:-20,z2:-16})}
/* construção abandonada */
const D={stuck:0,open:0},dp=new T.Vector3(6.5,1.2,-34),wm=mat(0xffffff,tex('#4a3b2c','0,0,0',2));
wall(6.5,11.5,-36.2,-36,2.6,wm);wall(6.5,11.5,-32,-31.8,2.6,wm);wall(11.5,11.7,-36,-32,2.6,wm);wall(6.4,6.6,-36,-34.6,2.6,wm);wall(6.4,6.6,-33.4,-32,2.6,wm);
box(6.4,6.6,2.2,2.6,-34.6,-33.4,wm);box(6.5,11.5,-.05,.05,-36,-32,mat(0x2a2018));
const roof=box(6.1,11.9,2.6,2.8,-36.6,-31.4,mat(0x2d2a28));roof.rotation.z=-.07;
const doorR={x1:6.4,x2:6.6,z1:-34.6,z2:-33.4};walls.push(doorR);
const door=new T.Group();door.position.set(6.5,0,-34.6);const dm=new T.Mesh(new T.BoxGeometry(.12,2.2,1.2),mat(0x5a4632));dm.position.set(0,1.1,.6);door.add(dm);sc.add(door);
box(9,10.2,0,.8,-34.4,-33.6,mat(0x3a2c20));box(9.3,9.9,.81,.83,-34.3,-33.9,new T.MeshBasicMaterial({color:0x6e6a58}));
{const b=new T.Mesh(new T.CylinderGeometry(.45,.45,1,8),mat(0x4a2a1a));b.position.set(5.2,.5,-30.5);sc.add(b)}
/* chuva */
const RN=550,rp=new Float32Array(RN*6),rl=[];for(let i=0;i<RN;i++){rl.push([rr(-14,14),rr(0,12),rr(-14,14)])}
const rg=new T.BufferGeometry();rg.setAttribute('position',new T.BufferAttribute(rp,3));const rain=new T.LineSegments(rg,new T.LineBasicMaterial({color:0x7a8fa8,transparent:true,opacity:.4}));rain.frustumCulled=false;sc.add(rain);
/* lanterna */
const sp=new T.SpotLight(0xfff0d0,2.6,32,.45,.6,1.2);sp.position.set(.1,-.1,0);sp.target.position.set(0,0,-1);cam.add(sp,sp.target);
const fm=new T.Mesh(new T.CylinderGeometry(.035,.045,.26,8),mat(0x222222));fm.rotation.x=Math.PI/2;fm.position.set(.26,-.24,-.5);cam.add(fm);
const Fl={on:false,t:0,toggle(){this.on=!this.on;this.t=.4;A.tone(900,350,.05,.2,'square');A.burst(1500,.04,.15);$('fl').style.opacity=this.on?1:.45;$('bLight').classList.toggle('on',this.on)}};
/* observador */
const W=new T.Group();{const bk=new T.MeshBasicMaterial({color:0x000000}),a=new T.Mesh(new T.BoxGeometry(.5,1.9,.3),bk),h=new T.Mesh(new T.SphereGeometry(.2,6,5),bk);h.position.y=1.15;const ey=new T.MeshBasicMaterial({color:0xb02020});[-.07,.07].forEach(x=>{const e=new T.Mesh(new T.SphereGeometry(.025,4,4),ey);e.position.set(x,1.17,.17);W.add(e)});a.position.y=.2;W.add(a,h);W.visible=false;sc.add(W)}
const Wt={next:15,lit:0};
/* ===== INTERAÇÃO ===== */
const objs=[{x:carP.x,z:carP.z,r:3.4,l:'Examinar o veículo',fn(){Save.d.f.car=1;Inv.give('d1','Ficha de entrega — Estrada de Blackwood','Destino: Hospital Saint Mary.\nRemetente: [riscado].\n\nNa margem, à caneta, letra trêmula:\n“93,7 — ela ainda escuta.\nNão pare perto da estação.”');A.creak(carP);check()}},
{x:6.5,z:-34,r:2.2,l:'Examinar a porta',fn(){if(!D.stuck){D.stuck=1;A.tone(60,45,.8,.4,'sawtooth',dp);sub('A porta está emperrada.')}else if(!D.open){D.open=1;doorR.x1=doorR.x2=doorR.z1=doorR.z2=1e9;door.rotation.y=-1.6;A.creak(dp);sub('A porta cede, rangendo.')}else sub('Está escuro lá dentro.')}},
{x:9.6,z:-34,r:1.5,l:'Examinar a mesa',fn(){if(!D.open)return sub('Não alcanço.');Save.d.f.shed=1;Inv.give('d2','Mapa rasgado','Estrada de Blackwood — 4 km.\nUm círculo vermelho marca “Hospital Saint Mary”.\n\nNo verso:\n“Elena não está sozinha.”');check()}}];
let cur=null;function interact(){cur=null;let best=9;const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);
for(const o of objs){if(o.l==='Examinar a mesa'&&!D.open)continue;const dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz);if(d<o.r&&(d<1.5||(dx*fx+dz*fz)/d>.35)&&d<best){best=d;cur=o}}
$('pr').textContent=cur?'● '+cur.l:'';$('pr').style.opacity=cur?1:0;$('bUse').classList.toggle('on',!!cur)}
$('bUse').onclick=()=>{if(cur)cur.fn();else sub('Nada aqui.',1500)};
/* ===== CONTROLES ===== */
const In={mx:0,mz:0,run:false};
function zone(el,mv,up){let id=null,ox,oy,lx,ly;el.onpointerdown=e=>{if(id!==null)return;id=e.pointerId;ox=lx=e.clientX;oy=ly=e.clientY;el.setPointerCapture(id);mv(0,0,0,0,ox,oy)};
el.onpointermove=e=>{if(e.pointerId!==id)return;mv(e.clientX-ox,e.clientY-oy,e.clientX-lx,e.clientY-ly,ox,oy);lx=e.clientX;ly=e.clientY};
el.onpointerup=el.onpointercancel=e=>{if(e.pointerId!==id)return;id=null;up()}}
const jb=$('jb'),jk=$('jk');
zone($('zl'),(dx,dy,a,b,ox,oy)=>{const l=Math.hypot(dx,dy),k=Math.min(l,60)/60,an=Math.atan2(dy,dx);In.mx=l?Math.cos(an)*k:0;In.mz=l?-Math.sin(an)*k:0;jb.style.display='block';jb.style.left=ox+'px';jb.style.top=oy+'px';jk.style.transform='translate('+(In.mx*45)+'px,'+(-In.mz*45)+'px)'},()=>{In.mx=In.mz=0;jb.style.display='none'});
zone($('zr'),(dx,dy,ddx,ddy)=>{P.yaw-=ddx*.006;P.pitch=cl(P.pitch-ddy*.006,-1.2,1.2)},()=>{});
$('bLight').onclick=()=>Fl.toggle();$('bRadio').onclick=openRadio;
$('bRun').onclick=()=>{In.run=!In.run;$('bRun').classList.toggle('on',In.run)};
/* ===== LOOP ===== */
let S=.6,fr=0,ft=0,lastFoot=0,nextAmb=6;const ck=new T.Clock();
function size(){const w=innerWidth,h=innerHeight;rd.setSize(Math.max(160,w*S|0),Math.max(120,h*S|0),false);cam.aspect=w/h;cam.updateProjectionMatrix()}
addEventListener('resize',size);size();
function hit(x,z){const r=.4;for(const w of walls)if(x>w.x1-r&&x<w.x2+r&&z>w.z1-r&&z<w.z2+r)return true;for(const t of trees)if(Math.abs(t.x-x)<.8&&Math.abs(t.z-z)<.8&&Math.hypot(t.x-x,t.z-z)<.7)return true;return false}
function tick(){requestAnimationFrame(tick);const dt=Math.min(ck.getDelta(),.05),now=ck.elapsedTime;
const sp_=In.run?4.3:2.2,fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw);
const vx=(fx*In.mz+rx*In.mx)*sp_*dt,vz=(fz*In.mz+rz*In.mx)*sp_*dt;
if(!hit(P.x+vx,P.z))P.x+=vx;if(!hit(P.x,P.z+vz))P.z+=vz;P.x=cl(P.x,-44,44);P.z=cl(P.z,-100,30);
const mv=Math.hypot(In.mx,In.mz);if(mv>.1){P.bob+=dt*sp_*2.6;if(Math.floor(P.bob/Math.PI)!==lastFoot){lastFoot=Math.floor(P.bob/Math.PI);A.burst(500,.1,.12)}}
cam.position.set(P.x,1.7+Math.sin(P.bob)*.045*mv,P.z);cam.rotation.set(P.pitch,P.yaw,Math.sin(P.bob*.5)*.008*mv,'YXZ');
/* lanterna */
Fl.t=Math.max(0,Fl.t-dt);sp.intensity=Fl.on?(Fl.t>0?(R()<.5?.2:2.6):2.6):0;fm.position.y=-.24+(Fl.on?0:-.08)+Math.sin(P.bob)*.01*mv;
/* chuva */
rain.position.set(P.x,0,P.z);for(let i=0;i<RN;i++){const q=rl[i];q[1]-=dt*16;if(q[1]<0)q[1]=12;const o=i*6;rp[o]=q[0];rp[o+1]=q[1];rp[o+2]=q[2];rp[o+3]=q[0]+.05;rp[o+4]=q[1]-.7;rp[o+5]=q[2]}rg.attributes.position.needsUpdate=true;
sc.fog.density=.05+Math.sin(now*.2)*.006;if(Fx.carL)Fx.carL.intensity=R()<.03?.2:.9;
/* observador */
Wt.next-=dt;if(Wt.next<0&&!W.visible){const a=P.yaw+(R()<.5?-1:1)*rr(.5,1.2),d=rr(16,24),x=P.x-Math.sin(a)*d,z=P.z-Math.cos(a)*d;if(Math.abs(x)>6&&x>-46&&x<46){W.position.set(x,0,z);W.visible=true;Wt.lit=0}else Wt.next=1}
if(W.visible){W.lookAt(P.x,0,P.z);const dx=W.position.x-P.x,dz=W.position.z-P.z,d=Math.hypot(dx,dz),dot=(dx*fx+dz*fz)/d;
if(Fl.on&&dot>.93&&d<27)Wt.lit+=dt;else Wt.lit=Math.max(0,Wt.lit-dt*.5);
if(Wt.lit>1.3||d<9){W.visible=false;Wt.next=rr(20,35);A.tone(300,40,.6,.25,'sawtooth',new T.Vector3(W.position.x,1,W.position.z));if(d<9)sub('Algo se mexeu entre as árvores.',3000)}}
/* áudio ambiente */
if(A.c){A.listen();if(now>nextAmb){nextAmb=now+rr(7,16);const k=R();if(k<.4)A.creak(carP);else if(k<.7)A.creak(dp);else A.tone(260,80,.08,.3,'square',new T.Vector3(P.x+rr(-20,20),1,P.z+rr(-20,20)))}Radio.update()}
interact();rd.render(sc,cam);
fr++;ft+=dt;if(ft>2){const f=fr/ft;$('fps').textContent=Math.round(f)+' fps';if(f<32&&S>.4){S-=.1;size()}fr=0;ft=0}}
/* ===== INÍCIO ===== */
const had=Save.load();if(had){$('go').textContent='Continuar';$('nw').style.display='block'}
function begin(){A.init();A.c.resume&&A.c.resume();try{speechSynthesis.getVoices()}catch(e){}
try{document.documentElement.requestFullscreen&&document.documentElement.requestFullscreen();screen.orientation&&screen.orientation.lock('landscape').catch(()=>{})}catch(e){}
const p=Save.d.p;P.x=p[0];P.z=p[1];P.yaw=p[2];Radio.f=100;$('st').style.display='none';
sub(had?'Retomando a estrada...':'O rádio não parou de chiar desde que saí de casa. Preciso seguir as coordenadas.',6000);
setInterval(()=>Save.put(),10000);tick()}
$('go').onclick=begin;$('nw').onclick=()=>{Save.reset();location.reload()};
$('ld').textContent='Pronto.';
})();
